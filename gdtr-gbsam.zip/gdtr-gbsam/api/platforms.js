﻿(function () {

	var checkPlatform = function (platform) {
		if (!(Checks.checkPropertiesPresent(platform, ['id', 'name', 'startAmount', 'unitsSold', 'licencePrize', 'published', 'platformRetireDate', 'developmentCosts', 'genreWeightings', 'audienceWeightings', 'techLevel', 'iconUri'])
			&& Checks.checkUniqueness(platform, 'id', Platforms.allPlatforms)
			&& Checks.checkAudienceWeightings(platform.audienceWeightings)
			&& Checks.checkGenreWeightings(platform.genreWeightings)))
			return false;

		if (!(Checks.checkDate(platform.published)
			&& Checks.checkDate(platform.platformRetireDate)))
			return false;

		if (platform.marketPoints) {
			for (var i = 0; i < platform.marketPoints.length; i++) {
				if (!Checks.checkDate(platform.marketPoints[i].date))
					return false;
			}
		}

		return true;
	};


		Examples.addPlatform = function () {
		var icon = GDT.getRelativePath() + '/examples/img/greenheartOne.png';
		GDT.addPlatform(
			{
				id: 'BlamoPower',
				name: 'BlamoPower',
				company: 'justasip studios',
				startAmount: 0.15,
				unitsSold: 870.783,
				licencePrize: 5000,
				published: '1/3/4',
				platformRetireDate: '20/11/11',
				developmentCosts: 10000,
				genreWeightings: [1, 1, 1, 1, 1, 1],
				audienceWeightings: [1, 1, 1],
				techLevel: 100,
				iconUri: icon,
				events: [
					{
						id: '10537DA1-58F1-4F23-8854-F1E2621933BF',
						date: '1/2/1',
						getNotification: function (company) {
							return new Notification({
								header: "Industry News".localize(),
								text: "A famos indle studio, justasip studios, will known for games like 'Swoop Rancher', has release their first console, it's good tech, with a good price the people can afford, even going to release an engine for everyone for the console. The CEO stated, "It's been a while sence we been working on games, look on the bright side, bringing tech like 3D and VR! Only 99$, it'll start shipping next month."" " {0}.".localize().format(General.getETADescription('1/2/1', '1/3/4')),
								image: icon
							});
						}
					}
				]
			});
	};
	
	GDT.addPlatform = function (platform) {
		if (!checkPlatform(platform))
			return;

		Platforms.allPlatforms.push(platform);
		if (platform.events) {
			for (var i = 0; i < platform.events.length; i++) {
				GDT.addEvent(platform.events[i]);
			}
		}
	};
})();