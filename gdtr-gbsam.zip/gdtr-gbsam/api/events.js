﻿(function () {
	GDT.addEvent = function (event) {
		if (!Checks.checkPropertiesPresent(event, ['id'])
			&& (event.notification || event.getNotification))
			return;
		if (!Checks.checkUniqueness(event, 'id', DecisionNotifications.modNotifications))
			return;

		DecisionNotifications.modNotifications.push(event);
	}
})();

	Examples.addEvent = function () {
		/*
		example event:
		when does it fire: random event, only in the first office when a game is in development
		what happens: neighbours kid spies on game dev, resulting in several options.
		*/

		var eventId = "F413351E-2108-4967-A989-A7E98D4DEED5";//any string, but needs to be globally unique

		var myRandomEvent = {
			id: eventId,
			isRandom: true, //if you want to test this event, you can set this to false and it will trigger during dev. of the first game.
			maxTriggers: 1,
			trigger: function (company) {
				//only in first office and only while a game is in development.
				//most events that fire during game-dev work better if they don't fire right at the start or right at the end, that's why we use isGameProgressBetween
				return company.currentLevel == 1 && company.isGameProgressBetween(0.2, 0.9);
			},
			//because we dynamically create the notification every time the event triggers, we use getNotification
			getNotification: function (company) {
				var game = company.currentGame;

				var msg = "It's found that kids and teens have been finding out the up-coming game files were leaked. {0}. Rumour has it, that Tom, your next-door neighbour's kid, and look at the game files, when you and his parents have been cooling outside, he got inside the garage, used his UBS Stick, and save the files.{n}The classmates have heard of it, and told their siblings.\nWhat would you do?\n\nYou could talk to his parents to get him punished, ignore the incident, or you can tell the game files were fake, it's the quickest and easiest, but you've been lying to yoor fans.."
					.localize().format(game.title);
				//notice how we break up the story in two screens by using {n}. This creates a better flow than having one longer block of text.
				//Also, since this is a story with multiple options and the buttons can only hold a small amount of text, we explain the options beforehand.

				//the chatting among kids, creates a bit of hype.
				//since the event isn't delayed we can do this directly on the company, otherwise we could call adjustHype() on the notification object to schedule the effect with the notification.
				company.adjustHype(5 + 10 * company.getRandom());//increase hype between 5 and 15.

				return new Notification({
					sourceId: eventId,//this is important, otherwise nothing will happen when the player selects an option.
					header: "Tom, the kid".localize(),//granted, this is a silly header.
					text: msg,
					options: ["Talk to parents".localize(), "Ignore incident".localize(), "Lye to fans".localize()]//maximum of three choices
				});
			},
			complete: function (decision) {
				//decision is a number and will correspond to the index of the option that was chosen.
				//0=talk to parents, 1=ignore incident, 2=invite over
				//it's best if every decision has a different outcome

				var company = GameManager.company;//we fetch the company object for use later.

				if (decision === 0) {//talk to parents
					//we create a new, simple notification to tell the outcome. no sourceId or options are necessary this time.
					var n = new Notification({
						header: "Tom got Ground!".localize(),//keep the header consistent with the prior part of the story
						text: "After you calling Tom's Parents, Tom got ground for a week, and his USBs were burned, but the leaked files were givin to you! (with bad images of Tom drawing)".localize()
					});
					n.adjustHype(5 + 10 * company.getRandom());//increase hype between 5 and 15.

					company.activeNotifications.addRange(n.split()); //since this notificaton should be shown immediately (not one second later) we insert it into activeNotifications. calling .split() ist just good practice in case we use {n} inside the notification.
					return;
				}
				if (decision === 1) {//ignore incident
					//nothing happens at first, but in a few weeks Billy again breaks in...
					var n = new Notification({
						header: "Got sued.".localize(),
						text: "Tom's family have sued you because he lyied saying this is a threat to him.\nLuckly, you told his parents that he STOLE THEM, and they were nothing to him, and he got GROUNDED!, but you have still to pay the fine you got (-500 cr.) - Is better to know what could happen.".localize(),
						weeksUntilFired: 1 + 2 * company.getRandom()
					});
					n.adjustCash(-500, "restoring documents");
					company.notifications.push(n);//this notification isn't shown immediately so we add it to the normal company.notifications array.
					return;
				}
				if (decision === 2) {//invite him over
					var n = new Notification({
						header: "Haters!".localize(),//keep the header consistent with the prior part of the story
						text: "You decided to lye that they were fake, but fans found out you've been lying, now they hate you for that.".localize()
					});
					n.adjustFans(-100)
					company.activeNotifications.addRange(n.split()); //since this notificaton should be shown immediately (not one second later) we insert it into activeNotifications. calling .split() ist just good practice in case we use {n} inside the notification.
					return;
				}
			}
		};

		GDT.addEvent(myRandomEvent);
	};
